# COMPLYSTACK
## RegTech + Explainable AI for NDPA Compliance
### Nigeria-First, Export-Ready Compliance-as-a-Service

---

## What You Have

This package contains a **complete, production-oriented prototype** of ComplyStack — a multi-regulator compliance platform built specifically for Nigeria's NDPA 2023, GAID 2025, CBN, NCC, ngCERT, and NCP 2025 frameworks, architected to export to Kenya, Ghana, and South Africa.

### Files Included

| File | Description |
|------|-------------|
| `complystack_app.html` | **High-fidelity frontend SPA** — 8 screens, responsive design, interactive XAI visualizations. Open in any browser. |
| `complystack_backend.py` | **Flask backend** — SQLAlchemy models, XAI engine (SHAP/LIME), API routes, multi-regulator breach orchestration, CAR filing logic. |
| `complystack_architecture.png` | System architecture diagram (6 layers, microservices-ready). |
| `complystack_ui_mockups.png` | UI/UX mockups (Dashboard, Breach Orchestrator, XAI DPIA, Pricing). |
| `complystack_journey_data.png` | User journey flow + Data Mapping engine diagram. |

---

## Quick Start

### 1. Frontend (No Server Required)
```bash
# Simply open the HTML file in your browser
open complystack_app.html
# Or drag it into Chrome/Firefox/Safari
```

The frontend is a fully interactive single-page application with:
- **Dashboard** — Real-time health scoring, priority actions, XAI insights
- **Data Mapping** — Auto-discovery simulation, ROPA generation, NCP 2025 localization check
- **DPIA Builder** — Interactive SHAP waterfall chart with mitigation measures
- **Consent Manager** — Blockchain-ledgered consent records with withdrawal workflow
- **Breach Response** — Multi-regulator orchestrator (NDPC/CBN/NCC/ngCERT) with XAI decision trace
- **Cross-Border Manager** — Transfer Impact Assessment tracking, adequacy checks
- **CAR Filing** — GAID Schedule 2 checklist, auto-generated audit pack
- **DPCO Marketplace** — Licensed compliance organization directory
- **Pricing & Export** — SME-tiered pricing, jurisdictional portability framework

### 2. Backend (Python + Flask)
```bash
# Install dependencies
pip install flask flask-sqlalchemy flask-cors

# Run the API server
python complystack_backend.py

# Server starts on http://localhost:5000
```

### 3. API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/health` | GET | Service health check |
| `/api/organizations` | POST | Create new organization |
| `/api/organizations/<id>` | GET | Get organization profile |
| `/api/organizations/<id>/health` | GET | Compliance health score + DCPMI tier prediction |
| `/api/organizations/<id>/dpias` | POST | Create DPIA with XAI risk assessment |
| `/api/organizations/<id>/breaches` | POST | Report breach with multi-regulator XAI classification |
| `/api/organizations/<id>/consent` | POST | Record consent with blockchain hash |
| `/api/organizations/<id>/consent/<id>/withdraw` | POST | Process consent withdrawal |
| `/api/organizations/<id>/car/status` | GET | CAR filing status, fees, deadlines |
| `/api/organizations/<id>/data-mapping` | GET | Auto-generated ROPA + NCP 2025 localization check |
| `/api/dpcos` | GET | List licensed DPCOs with ratings and pricing |

### 4. Test the XAI Engine
```bash
# After starting the backend, create an organization
curl -X POST http://localhost:5000/api/organizations \
  -H "Content-Type: application/json" \
  -d '{"name":"Test Fintech","sector":"fintech","email":"test@example.com","data_subject_count":8500}'

# The response includes DCPMI tier prediction and health score

# Create a processing activity, then run DPIA
curl -X POST http://localhost:5000/api/organizations/1/dpias \
  -H "Content-Type: application/json" \
  -d '{"processing_activity_id":1,"title":"AI Credit Scoring DPIA"}'

# The response includes SHAP feature contributions and mitigation measures
```

---

## Architecture Highlights

### XAI Engine (Not Black-Box)
Every automated decision is explainable:
- **SHAP waterfall charts** show exactly which factors drove a DPIA risk score
- **LIME local explanations** justify individual breach severity classifications
- **Decision traces** document why CBN was triggered but NCC was not
- All explanations are legally defensible under NDPA Section 28 (Accountability)

### Multi-Regulator Orchestration
Nigeria's unique complexity is handled natively:
- **NDPC**: 72-hour breach notification, DCPMI registration, CAR filing
- **CBN**: Cybersecurity Self-Assessment (CSAT), FinCERT reporting
- **NCC**: 48-hour consumer breach notification, CSIRT incident templates
- **ngCERT**: 72-hour cyber threat reporting via sectoral CERT
- **NCP 2025**: Data localization engine classifies sovereign vs. personal vs. metadata

### Jurisdiction-Agnostic Core
The platform is built for export:
1. **Regulatory Knowledge Graph** encodes Nigeria's rules as a swappable module
2. Swap the graph → instant compliance for GDPR (EU), POPIA (South Africa), DPA (Kenya/Ghana)
3. Same XAI engine, same data model, same API — different regulatory logic

---

## Pricing Model (SME-Optimized)

| Tier | Price | Subjects | Key Features |
|------|-------|----------|--------------|
| **Micro** | ₦15,000/mo | ≤200 | ROPA, Privacy Policy, Email Support |
| **Growth** | ₦45,000/mo | ≤2,000 | +DPIA Builder, Consent Manager, DPO Chatbot |
| **DCPMI** | ₦120,000/mo | ≤10,000 | +CAR Filing, Breach Orchestrator, DPCO Marketplace |
| **Enterprise** | Custom | Unlimited | Multi-entity, White-label, API Access, GDPR/POPIA modules |

**vs. Traditional DPCO Consulting**: ₦3.5M–₦8M/year → **85-95% cost reduction**

---

## Legal Safeguards Built In

1. **DPCO Liability Firewall**: ComplyStack is a technology platform, not a DPCO. CAR filing requires a licensed DPCO verification statement (GAID Section 12.4). We generate the audit pack; the DPCO reviews and signs.

2. **XAI Audit Trail**: Every decision is logged with SHAP values, timestamps, and model versions — creating a legally defensible record for NDPC audits and court challenges.

3. **NCP 2025 by Design**: Data localization engine defaults to Nigerian hosting for sovereign data and requires explicit TIA documentation for cross-border transfers.

4. **Sectoral Specificity**: Fintech users cannot accidentally use generic templates — CBN + FinCERT routing is enforced by default.

5. **Penalty Avoidance**: Automated deadline tracking for DCPMI registration, CAR filing (March 31), and breach windows (72h NDPC, 48h NCC, 72h ngCERT).

---

## Technology Stack

| Layer | Technology |
|-------|------------|
| Frontend | HTML5, CSS3, Vanilla JS (SPA architecture) |
| Backend API | Python 3.10+, Flask, SQLAlchemy |
| Database | PostgreSQL (production) / SQLite (development) |
| XAI | SHAP + LIME simulation (production: integrate shap library) |
| NLP | spaCy / transformers for policy parsing (production) |
| Blockchain | SHA-256 audit hashes (production: Hyperledger Fabric or Ethereum) |
| Cloud | AWS/Azure/GCP with NCP 2025 localization engine |

---

## Next Steps for Production

1. **Replace mock data** with real database connections (PostgreSQL)
2. **Integrate SHAP library** (`pip install shap`) for production-grade explanations
3. **Add OAuth 2.0 + MFA** for authentication
4. **Build DPCO API bridge** for direct NDPC portal submission
5. **Implement anomaly detection** using Isolation Forest or LSTM for breach discovery
6. **Add USSD fallback** for low-bandwidth Nigerian SME users
7. **License as DPCO-Enabler** with NDPC (platform does not replace DPCOs)

---

## License

MIT License — Free for Nigerian SME ecosystem development.

**Built for Africa. Exportable to the world.**
