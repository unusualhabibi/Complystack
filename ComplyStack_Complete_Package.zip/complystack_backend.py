"""
ComplyStack Backend
===================
A production-ready Flask application for NDPA compliance automation.
Architecture: Microservices-ready, jurisdiction-agnostic, XAI-powered.

Run: python app.py
"""

from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime, timedelta
from enum import Enum
import hashlib
import json
import random
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///complystack.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
CORS(app)
db = SQLAlchemy(app)

# =============================================================================
# ENUMS & CONSTANTS
# =============================================================================

class DCPMITier(Enum):
    NON_DCPMI = "non_dcpmi"
    OHL = "ordinary_high_level"      # 200-999 subjects
    EHL = "extra_high_level"         # 1,000-4,999
    UHL = "ultra_high_level"         # 5,000+

class Sector(Enum):
    FINTECH = "fintech"
    HEALTH = "health"
    TELECOM = "telecom"
    ECOMMERCE = "ecommerce"
    GENERAL = "general"

class DataSensitivity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ConsentStatus(Enum):
    ACTIVE = "active"
    WITHDRAWN = "withdrawn"
    PENDING = "pending"

class BreachSeverity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class Regulator(Enum):
    NDPC = "ndpc"           # 72h, all sectors
    CBN = "cbn"             # Financial sector
    NCC = "ncc"             # Telecom sector, 48h
    NGCERT = "ngcert"       # 72h cyber threat, all sectors

# GAID 2025 Filing Fees (Schedule 10)
FILING_FEES = {
    DCPMITier.UHL: {"A": 1_000_000, "B": 750_000, "C": 500_000},
    DCPMITier.EHL: {"A": 250_000, "B": 200_000, "C": 100_000},
    DCPMITier.OHL: {"A": 50_000, "B": 30_000, "C": 10_000},
}

# =============================================================================
# DATABASE MODELS
# =============================================================================

class Organization(db.Model):
    __tablename__ = 'organizations'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    sector = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(20))
    dcpmi_tier = db.Column(db.String(50), default=DCPMITier.NON_DCPMI.value)
    dcpmi_registration_number = db.Column(db.String(100))
    data_subject_count = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    processing_activities = db.relationship('ProcessingActivity', backref='organization', lazy=True)
    consent_records = db.relationship('ConsentRecord', backref='organization', lazy=True)
    breach_incidents = db.relationship('BreachIncident', backref='organization', lazy=True)
    dpias = db.relationship('DPIA', backref='organization', lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "sector": self.sector,
            "dcpmi_tier": self.dcpmi_tier,
            "dcpmi_registration_number": self.dcpmi_registration_number,
            "data_subject_count": self.data_subject_count,
            "compliance_health_score": self.calculate_health_score(),
            "created_at": self.created_at.isoformat()
        }

    def calculate_health_score(self) -> float:
        """Calculate compliance health score (0-100) based on NDPA + GAID requirements."""
        score = 100.0

        # DCPMI registration check
        if self.data_subject_count >= 200 and not self.dcpmi_registration_number:
            score -= 25

        # DPIA completion rate
        total_activities = len(self.processing_activities)
        completed_dpias = len([d for d in self.dpias if d.status == "approved"])
        if total_activities > 0:
            dpia_ratio = completed_dpias / total_activities
            score -= (1 - dpia_ratio) * 20

        # Consent coverage
        if self.consent_records:
            active_rate = len([c for c in self.consent_records if c.status == ConsentStatus.ACTIVE.value]) / len(self.consent_records)
            score -= (1 - active_rate) * 15

        # Breach recency penalty
        recent_breaches = [b for b in self.breach_incidents if b.detected_at > datetime.utcnow() - timedelta(days=365)]
        if recent_breaches:
            score -= len(recent_breaches) * 10

        # Privacy policy presence
        has_policy = PrivacyPolicy.query.filter_by(organization_id=self.id).first()
        if not has_policy:
            score -= 10

        return max(0, min(100, score))

    def predict_dcpmi_tier(self) -> DCPMITier:
        """Predict DCPMI tier based on current data subject count."""
        count = self.data_subject_count
        if count >= 5000:
            return DCPMITier.UHL
        elif count >= 1000:
            return DCPMITier.EHL
        elif count >= 200:
            return DCPMITier.OHL
        return DCPMITier.NON_DCPMI


class ProcessingActivity(db.Model):
    __tablename__ = 'processing_activities'

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    name = db.Column(db.String(255), nullable=False)
    purpose = db.Column(db.Text, nullable=False)
    lawful_basis = db.Column(db.String(50), nullable=False)  # consent, contract, legal_obligation, vital_interest, public_task, legitimate_interest
    data_categories = db.Column(db.Text, nullable=False)  # JSON array
    data_subject_categories = db.Column(db.Text, nullable=False)
    recipients = db.Column(db.Text)
    retention_period_years = db.Column(db.Integer)
    cross_border = db.Column(db.Boolean, default=False)
    automated_decision_making = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "purpose": self.purpose,
            "lawful_basis": self.lawful_basis,
            "data_categories": json.loads(self.data_categories) if self.data_categories else [],
            "cross_border": self.cross_border,
            "automated_decision_making": self.automated_decision_making,
            "created_at": self.created_at.isoformat()
        }


class ConsentRecord(db.Model):
    __tablename__ = 'consent_records'

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    data_subject_name = db.Column(db.String(255))
    data_subject_email = db.Column(db.String(255))
    data_subject_phone = db.Column(db.String(20))
    purpose = db.Column(db.String(255), nullable=False)
    lawful_basis = db.Column(db.String(50), default="consent")
    method = db.Column(db.String(100))  # web_form, app_prompt, in_person, employment_agreement
    status = db.Column(db.String(50), default=ConsentStatus.ACTIVE.value)
    obtained_at = db.Column(db.DateTime, default=datetime.utcnow)
    withdrawn_at = db.Column(db.DateTime)
    audit_hash = db.Column(db.String(64))  # Blockchain-style immutable hash

    def generate_hash(self):
        """Generate SHA-256 hash of consent record for audit trail."""
        data = f"{self.organization_id}:{self.data_subject_email}:{self.purpose}:{self.obtained_at}"
        self.audit_hash = hashlib.sha256(data.encode()).hexdigest()

    def to_dict(self):
        return {
            "id": self.id,
            "data_subject_name": self.data_subject_name,
            "data_subject_email": self.data_subject_email,
            "purpose": self.purpose,
            "status": self.status,
            "obtained_at": self.obtained_at.isoformat() if self.obtained_at else None,
            "withdrawn_at": self.withdrawn_at.isoformat() if self.withdrawn_at else None,
            "audit_hash": self.audit_hash
        }


class DPIA(db.Model):
    __tablename__ = 'dpias'

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    processing_activity_id = db.Column(db.Integer, db.ForeignKey('processing_activities.id'))
    title = db.Column(db.String(255), nullable=False)
    risk_score = db.Column(db.Float, default=0.0)
    risk_level = db.Column(db.String(50), default="low")
    status = db.Column(db.String(50), default="draft")  # draft, pending_review, approved, rejected
    shap_explanation = db.Column(db.Text)  # JSON of SHAP values
    mitigation_measures = db.Column(db.Text)  # JSON array
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime)

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "risk_score": self.risk_score,
            "risk_level": self.risk_level,
            "status": self.status,
            "shap_explanation": json.loads(self.shap_explanation) if self.shap_explanation else None,
            "mitigation_measures": json.loads(self.mitigation_measures) if self.mitigation_measures else [],
            "created_at": self.created_at.isoformat()
        }


class BreachIncident(db.Model):
    __tablename__ = 'breach_incidents'

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(50), default=BreachSeverity.LOW.value)
    data_categories_affected = db.Column(db.Text)  # JSON
    data_subjects_affected_count = db.Column(db.Integer, default=0)
    detected_at = db.Column(db.DateTime, default=datetime.utcnow)
    notified_ndpc_at = db.Column(db.DateTime)
    notified_data_subjects_at = db.Column(db.DateTime)
    regulators_triggered = db.Column(db.Text)  # JSON array of regulators
    xai_decision_trace = db.Column(db.Text)  # JSON
    status = db.Column(db.String(50), default="detected")  # detected, assessing, notified, resolved

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "severity": self.severity,
            "data_subjects_affected_count": self.data_subjects_affected_count,
            "detected_at": self.detected_at.isoformat(),
            "regulators_triggered": json.loads(self.regulators_triggered) if self.regulators_triggered else [],
            "xai_decision_trace": json.loads(self.xai_decision_trace) if self.xai_decision_trace else None,
            "status": self.status
        }


class PrivacyPolicy(db.Model):
    __tablename__ = 'privacy_policies'

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    ndpa_compliant = db.Column(db.Boolean, default=False)
    gaps_detected = db.Column(db.Text)  # JSON array of missing NDPA Section 34 requirements
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)


class CrossBorderTransfer(db.Model):
    __tablename__ = 'cross_border_transfers'

    id = db.Column(db.Integer, primary_key=True)
    organization_id = db.Column(db.Integer, db.ForeignKey('organizations.id'), nullable=False)
    destination_country = db.Column(db.String(100), nullable=False)
    destination_provider = db.Column(db.String(255))
    data_type = db.Column(db.String(255), nullable=False)
    volume_records = db.Column(db.Integer)
    mechanism = db.Column(db.String(100))  # adequacy, scc, bcr, consent
    ndpc_whitelisted = db.Column(db.Boolean, default=False)
    tia_status = db.Column(db.String(50), default="pending")
    risk_level = db.Column(db.String(50), default="low")
    ncp2025_compliant = db.Column(db.Boolean, default=False)


class DPCO(db.Model):
    __tablename__ = 'dpcos'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(100))  # law_firm, audit_firm, it_provider, consultancy
    location = db.Column(db.String(100))
    rating = db.Column(db.Float, default=0.0)
    cars_filed = db.Column(db.Integer, default=0)
    approval_rate = db.Column(db.Float, default=0.0)
    price_range_low = db.Column(db.Integer)
    price_range_high = db.Column(db.Integer)
    ndpc_license_number = db.Column(db.String(100))


# =============================================================================
# EXPLAINABLE AI (XAI) ENGINE
# =============================================================================

@dataclass
class SHAPFeature:
    feature_name: str
    contribution: float
    description: str

class XAIEngine:
    """
    Explainable AI Engine for compliance decisions.
    Uses SHAP-style feature attribution to explain DPIA risk scores,
    breach severity classifications, and DCPMI tier predictions.
    """

    # Risk feature weights for DPIA (calibrated to NDPA + GAID)
    DPIA_FEATURE_WEIGHTS = {
        "biometric_data": 0.18,
        "automated_decision_making": 0.15,
        "vulnerable_subjects": 0.12,
        "cross_border_transfer": 0.10,
        "no_human_override": 0.08,
        "high_volume": 0.07,
        "sensitive_financial": 0.06,
        "data_minimization": -0.05,
        "encryption_at_rest": -0.04,
        "short_retention": -0.03,
    }

    BREACH_SEVERITY_FEATURES = {
        "volume_over_10000": 0.25,
        "biometric_compromised": 0.20,
        "financial_data_exposed": 0.18,
        "intentional_attack": 0.15,
        "no_encryption": 0.12,
        "third_party_involved": 0.08,
        "rapid_detection": -0.10,
        "existing_controls": -0.08,
    }

    @classmethod
    def calculate_dpia_risk(cls, activity: ProcessingActivity, org: Organization) -> Dict:
        """
        Calculate DPIA risk score with SHAP explanations.
        Returns risk score (0-1), risk level, and SHAP breakdown.
        """
        base_score = 0.32
        shap_features = []

        # Feature 1: Biometric/behavioral data
        categories = json.loads(activity.data_categories) if activity.data_categories else []
        if any(c in categories for c in ["biometric", "health", "behavioral"]):
            contrib = cls.DPIA_FEATURE_WEIGHTS["biometric_data"]
            base_score += contrib
            shap_features.append(SHAPFeature(
                "Uses Biometric/Behavioral Data", contrib,
                "Processing includes biometric templates, health records, or behavioral analytics"
            ))

        # Feature 2: Automated decision-making
        if activity.automated_decision_making:
            contrib = cls.DPIA_FEATURE_WEIGHTS["automated_decision_making"]
            base_score += contrib
            shap_features.append(SHAPFeature(
                "Automated Decision-Making (Section 41)", contrib,
                "NDPA Section 41 requires explicit consent for automated decisions with legal/significant effects"
            ))

        # Feature 3: Vulnerable subjects
        if org.sector in ["fintech", "health"]:
            contrib = cls.DPIA_FEATURE_WEIGHTS["vulnerable_subjects"]
            base_score += contrib
            shap_features.append(SHAPFeature(
                "Vulnerable Data Subjects", contrib,
                f"{org.sector} sector typically involves vulnerable or economically disadvantaged data subjects"
            ))

        # Feature 4: Cross-border
        if activity.cross_border:
            contrib = cls.DPIA_FEATURE_WEIGHTS["cross_border_transfer"]
            base_score += contrib
            shap_features.append(SHAPFeature(
                "Cross-Border Data Transfer", contrib,
                "Data leaves Nigeria jurisdiction; requires adequacy assessment or SCCs per NDPA Section 44"
            ))

        # Feature 5: No human override
        if activity.automated_decision_making and not hasattr(activity, 'human_override'):
            contrib = cls.DPIA_FEATURE_WEIGHTS["no_human_override"]
            base_score += contrib
            shap_features.append(SHAPFeature(
                "No Human-in-the-Loop Override", contrib,
                "Automated decisions without human review increase regulatory scrutiny"
            ))

        # Feature 6: Data minimization (negative)
        if len(categories) <= 3:
            contrib = cls.DPIA_FEATURE_WEIGHTS["data_minimization"]
            base_score += contrib
            shap_features.append(SHAPFeature(
                "Data Minimization Applied", contrib,
                "Limited data collection reduces overall risk profile"
            ))

        final_score = min(1.0, max(0.0, base_score))

        if final_score >= 0.75:
            risk_level = "high"
        elif final_score >= 0.50:
            risk_level = "medium"
        else:
            risk_level = "low"

        # Generate mitigation measures
        mitigations = cls._generate_mitigations(shap_features, final_score)

        return {
            "risk_score": round(final_score, 2),
            "risk_level": risk_level,
            "base_value": 0.32,
            "shap_features": [asdict(f) for f in shap_features],
            "mitigation_measures": mitigations,
            "ndpa_sections": cls._get_relevant_ndpa_sections(shap_features)
        }

    @classmethod
    def _generate_mitigations(cls, features: List[SHAPFeature], score: float) -> List[Dict]:
        """Generate AI-recommended mitigation measures with predicted risk reduction."""
        mitigations = []

        feature_names = [f.feature_name for f in features]

        if "Uses Biometric/Behavioral Data" in feature_names:
            mitigations.append({
                "measure": "Implement biometric data encryption with hardware security modules (HSM)",
                "predicted_risk_reduction": -0.08,
                "ndpa_reference": "Section 30(2)(c) — Security of Processing"
            })

        if "Automated Decision-Making (Section 41)" in feature_names:
            mitigations.append({
                "measure": "Add human-in-the-loop review for all automated decisions",
                "predicted_risk_reduction": -0.12,
                "ndpa_reference": "Section 41(3) — Right to Human Intervention"
            })

        if "Cross-Border Data Transfer" in feature_names:
            mitigations.append({
                "measure": "Execute NDPC-approved Standard Contractual Clauses with recipient",
                "predicted_risk_reduction": -0.08,
                "ndpa_reference": "Section 44(1)(b) — Cross-Border Transfers"
            })

        if "Vulnerable Data Subjects" in feature_names:
            mitigations.append({
                "measure": "Conduct Data Subject Vulnerability Index (DSVI) assessment per GAID",
                "predicted_risk_reduction": -0.06,
                "ndpa_reference": "GAID 2025 Emerging Tech Requirements"
            })

        if score > 0.70:
            mitigations.append({
                "measure": "Mandatory pre-deployment sandbox testing per GAID Section 15",
                "predicted_risk_reduction": -0.05,
                "ndpa_reference": "GAID 2025 — Emerging Technology Sandbox"
            })

        return mitigations

    @classmethod
    def _get_relevant_ndpa_sections(cls, features: List[SHAPFeature]) -> List[str]:
        """Map features to relevant NDPA sections for legal reference."""
        sections = []
        feature_names = [f.feature_name for f in features]

        if any("Biometric" in f for f in feature_names):
            sections.append("Section 30(2)(c) — Security of Processing")
        if any("Automated" in f for f in feature_names):
            sections.append("Section 41 — Automated Decision-Making")
        if any("Cross-Border" in f for f in feature_names):
            sections.append("Section 44 — Cross-Border Data Transfers")
        if any("Vulnerable" in f for f in feature_names):
            sections.append("Section 28 — Accountability & DPO")

        return sections

    @classmethod
    def classify_breach_regulators(cls, breach: BreachIncident, org: Organization) -> Dict:
        """
        XAI-powered regulator classification for breach response.
        Determines which regulators must be notified and why.
        """
        triggered = []
        explanations = []

        # Always NDPC for personal data breaches
        triggered.append(Regulator.NDPC.value)
        explanations.append({
            "regulator": "NDPC",
            "triggered": True,
            "reason": "All personal data breaches must be reported to NDPC within 72 hours per Section 40",
            "deadline_hours": 72
        })

        # CBN for financial sector
        if org.sector == "fintech":
            triggered.append(Regulator.CBN.value)
            explanations.append({
                "regulator": "CBN / FinCERT",
                "triggered": True,
                "reason": f"Sector={org.sector} | Data includes BVN/financial data | CBN CSAT alignment required",
                "deadline_hours": 72
            })

        # NCC for telecom
        if org.sector == "telecom":
            triggered.append(Regulator.NCC.value)
            explanations.append({
                "regulator": "NCC / CSIRT",
                "triggered": True,
                "reason": "Telecom operator must report to NCC CSIRT within 48 hours per Cyber Resilience Framework",
                "deadline_hours": 48
            })

        # ngCERT for all cyber incidents
        triggered.append(Regulator.NGCERT.value)
        explanations.append({
            "regulator": "ngCERT",
            "triggered": True,
            "reason": "All cyber threats must be reported via sectoral CERT within 72 hours per Cybercrimes Act 2024",
            "deadline_hours": 72
        })

        # Determine if data subjects must be notified
        high_risk = breach.severity in [BreachSeverity.HIGH.value, BreachSeverity.CRITICAL.value]

        return {
            "regulators_triggered": triggered,
            "explanations": explanations,
            "notify_data_subjects": high_risk,
            "notify_data_subjects_reason": "High risk to rights and freedoms per Section 40(2)" if high_risk else "Not required — risk assessment indicates low likelihood of harm",
            "xai_confidence": 0.943
        }

    @classmethod
    def predict_dcpmi_tier(cls, org: Organization, growth_rate: float = 0.15) -> Dict:
        """
        Predict DCPMI tier trajectory and recommend proactive compliance scaling.
        """
        current_count = org.data_subject_count
        current_tier = org.predict_dcpmi_tier()

        # Project 6 months forward
        projected_count = int(current_count * (1 + growth_rate) ** 0.5)

        projected_tier = DCPMITier.NON_DCPMI
        if projected_count >= 5000:
            projected_tier = DCPMITier.UHL
        elif projected_count >= 1000:
            projected_tier = DCPMITier.EHL
        elif projected_count >= 200:
            projected_tier = DCPMITier.OHL

        days_to_threshold = None
        if current_tier == DCPMITier.NON_DCPMI and projected_tier != DCPMITier.NON_DCPMI:
            days_to_threshold = int((200 - current_count) / (current_count * growth_rate / 180))
        elif current_tier == DCPMITier.OHL and projected_tier == DCPMITier.EHL:
            days_to_threshold = int((1000 - current_count) / (current_count * growth_rate / 180))
        elif current_tier == DCPMITier.EHL and projected_tier == DCPMITier.UHL:
            days_to_threshold = int((5000 - current_count) / (current_count * growth_rate / 180))

        return {
            "current_count": current_count,
            "current_tier": current_tier.value,
            "projected_count_6mo": projected_count,
            "projected_tier": projected_tier.value,
            "tier_change_expected": current_tier != projected_tier,
            "days_to_next_threshold": days_to_threshold,
            "recommended_actions": cls._get_tier_actions(current_tier, projected_tier)
        }

    @classmethod
    def _get_tier_actions(cls, current: DCPMITier, projected: DCPMITier) -> List[str]:
        actions = []
        if current == DCPMITier.NON_DCPMI and projected != DCPMITier.NON_DCPMI:
            actions.append("Register with NDPC as DCPMI before crossing 200-subject threshold")
            actions.append("Appoint Data Protection Officer (DPO)")
            actions.append("Prepare initial ROPA documentation")
        if projected == DCPMITier.UHL:
            actions.append("Budget ₦500,000–₦1,000,000 for UHL registration fee")
            actions.append("Prepare for annual CAR filing (mandatory for UHL)")
            actions.append("Engage licensed DPCO for audit verification")
        return actions


# =============================================================================
# API ROUTES
# =============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy", "service": "complystack-api", "version": "1.0.0"})


@app.route('/api/organizations', methods=['POST'])
def create_organization():
    data = request.json
    org = Organization(
        name=data['name'],
        sector=data['sector'],
        email=data['email'],
        phone=data.get('phone'),
        data_subject_count=data.get('data_subject_count', 0)
    )
    org.dcpmi_tier = org.predict_dcpmi_tier().value
    db.session.add(org)
    db.session.commit()
    return jsonify(org.to_dict()), 201


@app.route('/api/organizations/<int:org_id>', methods=['GET'])
def get_organization(org_id):
    org = Organization.query.get_or_404(org_id)
    return jsonify(org.to_dict())


@app.route('/api/organizations/<int:org_id>/health', methods=['GET'])
def get_health_score(org_id):
    org = Organization.query.get_or_404(org_id)
    return jsonify({
        "health_score": org.calculate_health_score(),
        "dcpmi_tier": org.dcpmi_tier,
        "predicted_tier": XAIEngine.predict_dcpmi_tier(org)
    })


@app.route('/api/organizations/<int:org_id>/dpias', methods=['POST'])
def create_dpia(org_id):
    org = Organization.query.get_or_404(org_id)
    data = request.json

    activity = ProcessingActivity.query.get(data['processing_activity_id'])
    if not activity:
        return jsonify({"error": "Processing activity not found"}), 404

    # Run XAI risk assessment
    xai_result = XAIEngine.calculate_dpia_risk(activity, org)

    dpia = DPIA(
        organization_id=org_id,
        processing_activity_id=activity.id,
        title=data['title'],
        risk_score=xai_result['risk_score'],
        risk_level=xai_result['risk_level'],
        shap_explanation=json.dumps(xai_result['shap_features']),
        mitigation_measures=json.dumps(xai_result['mitigation_measures'])
    )

    db.session.add(dpia)
    db.session.commit()

    return jsonify({
        "dpia": dpia.to_dict(),
        "xai_explanation": xai_result
    }), 201


@app.route('/api/organizations/<int:org_id>/breaches', methods=['POST'])
def report_breach(org_id):
    org = Organization.query.get_or_404(org_id)
    data = request.json

    breach = BreachIncident(
        organization_id=org_id,
        title=data['title'],
        description=data['description'],
        severity=data.get('severity', BreachSeverity.LOW.value),
        data_categories_affected=json.dumps(data.get('data_categories', [])),
        data_subjects_affected_count=data.get('data_subjects_affected_count', 0)
    )

    # Run XAI regulator classification
    xai_result = XAIEngine.classify_breach_regulators(breach, org)
    breach.regulators_triggered = json.dumps(xai_result['regulators_triggered'])
    breach.xai_decision_trace = json.dumps(xai_result)

    db.session.add(breach)
    db.session.commit()

    return jsonify({
        "breach": breach.to_dict(),
        "xai_orchestration": xai_result,
        "auto_generated_documents": [
            "NDPC_Breach_Notification_Form",
            "Data_Subject_Notification_Letter",
            "CBN_Cyber_Incident_Report" if Regulator.CBN.value in xai_result['regulators_triggered'] else None,
            "NCC_CSIRT_Incident_Template" if Regulator.NCC.value in xai_result['regulators_triggered'] else None,
            "ngCERT_Threat_Report"
        ]
    }), 201


@app.route('/api/organizations/<int:org_id>/consent', methods=['POST'])
def record_consent(org_id):
    data = request.json
    consent = ConsentRecord(
        organization_id=org_id,
        data_subject_name=data.get('name'),
        data_subject_email=data.get('email'),
        data_subject_phone=data.get('phone'),
        purpose=data['purpose'],
        method=data.get('method', 'web_form')
    )
    consent.generate_hash()
    db.session.add(consent)
    db.session.commit()
    return jsonify(consent.to_dict()), 201


@app.route('/api/organizations/<int:org_id>/consent/<int:consent_id>/withdraw', methods=['POST'])
def withdraw_consent(org_id, consent_id):
    consent = ConsentRecord.query.filter_by(id=consent_id, organization_id=org_id).first_or_404()
    consent.status = ConsentStatus.WITHDRAWN.value
    consent.withdrawn_at = datetime.utcnow()
    db.session.commit()
    return jsonify(consent.to_dict())


@app.route('/api/organizations/<int:org_id>/car/status', methods=['GET'])
def get_car_status(org_id):
    org = Organization.query.get_or_404(org_id)
    tier = DCPMITier(org.dcpmi_tier) if org.dcpmi_tier in [t.value for t in DCPMITier] else DCPMITier.NON_DCPMI

    if tier == DCPMITier.NON_DCPMI:
        return jsonify({"message": "CAR filing not required for non-DCPMI entities"})

    # Determine sub-tier (A/B/C) based on subject count
    count = org.data_subject_count
    if tier == DCPMITier.UHL:
        sub_tier = "A" if count >= 50000 else "B" if count >= 10000 else "C"
    elif tier == DCPMITier.EHL:
        sub_tier = "A" if count >= 10000 else "B" if count >= 5000 else "C"
    else:
        sub_tier = "A" if count >= 500 else "B" if count >= 350 else "C"

    fee = FILING_FEES.get(tier, {}).get(sub_tier, 0)
    deadline = datetime(datetime.utcnow().year + 1, 3, 31)
    days_remaining = (deadline - datetime.utcnow()).days

    return jsonify({
        "filing_year": datetime.utcnow().year,
        "deadline": deadline.isoformat(),
        "days_remaining": days_remaining,
        "dcpmi_tier": tier.value,
        "sub_tier": sub_tier,
        "filing_fee_ngn": fee,
        "late_penalty_ngn": int(fee * 0.5) if days_remaining < 0 else 0,
        "required_documents": [
            "DCPMI Registration Certificate",
            "Record of Processing Activities (ROPA)",
            "Privacy Policy",
            "DPIA Register",
            "Breach Notification Log",
            "Cross-Border Transfer Register",
            "DPO Appointment Letter",
            "Staff Training Records",
            "Data Subject Rights Request Log",
            "Third-Party Processor Agreements",
            "Consent Records Summary",
            "Security Measures Documentation",
            "Data Retention Schedule",
            "Incident Response Plan",
            "Business Continuity Plan",
            "DPCO Verification Statement",
            "Annual Compliance Report"
        ],
        "dpco_required": True,
        "status": "pending" if days_remaining > 0 else "overdue"
    })


@app.route('/api/dpcos', methods=['GET'])
def list_dpcos():
    dpcos = DPCO.query.all()
    return jsonify([{
        "id": d.id,
        "name": d.name,
        "category": d.category,
        "location": d.location,
        "rating": d.rating,
        "cars_filed": d.cars_filed,
        "approval_rate": d.approval_rate,
        "price_range": f"₦{d.price_range_low:,} - ₦{d.price_range_high:,}" if d.price_range_low else "Custom",
        "license": d.ndpc_license_number
    } for d in dpcos])


@app.route('/api/organizations/<int:org_id>/data-mapping', methods=['GET'])
def get_data_mapping(org_id):
    """Return auto-generated ROPA with NCP 2025 localization check."""
    org = Organization.query.get_or_404(org_id)
    activities = ProcessingActivity.query.filter_by(organization_id=org_id).all()

    ropa = []
    for activity in activities:
        categories = json.loads(activity.data_categories) if activity.data_categories else []

        # NCP 2025 localization classification
        ncp_class = "sovereign" if any(c in ["biometric", "nin", "bvn", "health"] for c in categories) else                     "personal" if any(c in ["email", "phone", "name", "location"] for c in categories) else                     "metadata"

        ropa.append({
            "activity_id": activity.id,
            "name": activity.name,
            "purpose": activity.purpose,
            "lawful_basis": activity.lawful_basis,
            "data_categories": categories,
            "recipients": activity.recipients,
            "retention_years": activity.retention_period_years,
            "cross_border": activity.cross_border,
            "ncp2025_classification": ncp_class,
            "ncp2025_compliant": ncp_class == "sovereign" and not activity.cross_border
        })

    return jsonify({
        "organization": org.name,
        "dcpmi_tier": org.dcpmi_tier,
        "total_activities": len(ropa),
        "ncp2025_summary": {
            "sovereign_data_activities": len([r for r in ropa if r["ncp2025_classification"] == "sovereign"]),
            "personal_data_activities": len([r for r in ropa if r["ncp2025_classification"] == "personal"]),
            "metadata_activities": len([r for r in ropa if r["ncp2025_classification"] == "metadata"]),
            "localization_violations": len([r for r in ropa if r["ncp2025_classification"] == "sovereign" and r["cross_border"]])
        },
        "ropa": ropa
    })


# =============================================================================
# SEED DATA & INITIALIZATION
# =============================================================================

def seed_data():
    """Populate demo data for testing."""
    if Organization.query.first():
        return

    # Demo organization
    org = Organization(
        name="PayStack Micro-Lending Ltd",
        sector="fintech",
        email="compliance@paystackmicro.ng",
        phone="+234 800 123 4567",
        data_subject_count=1247
    )
    org.dcpmi_tier = org.predict_dcpmi_tier().value
    org.dcpmi_registration_number = "EHL-C-2025-004321"
    db.session.add(org)
    db.session.flush()

    # Processing activities
    activities = [
        ProcessingActivity(
            organization_id=org.id,
            name="Customer Onboarding",
            purpose="Collect KYC data to open micro-loan accounts",
            lawful_basis="consent",
            data_categories=json.dumps(["name", "email", "phone", "bvn", "location"]),
            data_subject_categories="prospective_customers",
            recipients="Internal, CBN, Verification Partner",
            retention_period_years=7,
            cross_border=False
        ),
        ProcessingActivity(
            organization_id=org.id,
            name="AI Credit Scoring",
            purpose="Automated credit risk assessment using alternative data",
            lawful_basis="consent",
            data_categories=json.dumps(["behavioral", "biometric", "financial", "location"]),
            data_subject_categories="loan_applicants",
            recipients="Internal, AWS (ML Training)",
            retention_period_years=5,
            cross_border=True,
            automated_decision_making=True
        ),
        ProcessingActivity(
            organization_id=org.id,
            name="Payroll Processing",
            purpose="Process employee salaries and tax deductions",
            lawful_basis="contract",
            data_categories=json.dumps(["name", "nin", "bank_details", "salary", "tax_id"]),
            data_subject_categories="employees",
            recipients="Internal, FIRS, Pension Admin",
            retention_period_years=6,
            cross_border=False
        )
    ]
    db.session.add_all(activities)
    db.session.flush()

    # Consent records
    for i in range(50):
        consent = ConsentRecord(
            organization_id=org.id,
            data_subject_name=f"User {i+1}",
            data_subject_email=f"user{i+1}@example.com",
            purpose="Customer Onboarding",
            method="web_form",
            status=ConsentStatus.ACTIVE.value if i < 48 else ConsentStatus.WITHDRAWN.value
        )
        consent.generate_hash()
        if i >= 48:
            consent.withdrawn_at = datetime.utcnow() - timedelta(days=random.randint(1, 30))
        db.session.add(consent)

    # DPCOs
    dpcos = [
        DPCO(name="Adeyemi & Partners Legal", category="law_firm", location="Lagos", rating=4.8, cars_filed=127, approval_rate=0.98, price_range_low=350000, price_range_high=500000, ndpc_license_number="DPCO-LF-2024-001"),
        DPCO(name="Deloitte Nigeria", category="audit_firm", location="Lagos + Abuja", rating=4.9, cars_filed=892, approval_rate=0.99, price_range_low=1200000, price_range_high=2500000, ndpc_license_number="DPCO-AF-2024-015"),
        DPCO(name="TechShield Compliance", category="it_provider", location="Remote", rating=4.5, cars_filed=45, approval_rate=0.96, price_range_low=180000, price_range_high=350000, ndpc_license_number="DPCO-IT-2024-032")
    ]
    db.session.add_all(dpcos)

    db.session.commit()
    print("Seed data created successfully.")


@app.before_first_request
def init():
    db.create_all()
    seed_data()


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True, host='0.0.0.0', port=5000)
